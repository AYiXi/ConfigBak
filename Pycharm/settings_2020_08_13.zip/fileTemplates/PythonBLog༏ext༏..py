from scrapy_redis.spiders import RedisSpider
from scrapy import Request
from scrapy.http import TextResponse

from move_blog_spider.spiders.single.single import get_single_article_item, format_article_img_path


class AoyuehanzhiSpider(RedisSpider):
    name = ''
    username = ''
    redis_key = ':start_urls'

    def start_requests(self):
        page = 1
        for article_page in range(1, page + 1):
            if article_page == 1:
                article_url = ''
            else:
                article_url = ''.format(article_page)
            yield Request(article_url, self.parse_list_page, dont_filter=True)


    def parse_list_page(self, response):
            urlist = response.xpath('').extract()
            for url in urlist:
                yield Request('' + url, self.parse_detail_page, dont_filter=True)

    def parse_detail_page(self, response: TextResponse):
        self.logger.info('Start parse detail page {}.'.format(response.url))

        title_raw = response.xpath('').extract_first().strip()
        if not title_raw:
            self.logger.info('404.')
            return
        title = title_raw.strip()

        aid = response.url.split('')[1]

        date = response.xpath('').extract_first().strip()

        raw_article = response.xpath('').extract_first()
        article = format_article_img_path(raw_article, response.url)

        self.logger.info('Aid: {}.'.format(aid))
        self.logger.info('Title: {}.'.format(title))
        self.logger.info('Date: {}.'.format(date))

        # self.logger.info('Article content: {}.'.format(article))
        yield get_single_article_item(self.username, aid, title, date, article, response.url)

    def clean_date(self, date: str) -> str:
        pass